
local curl = require "lcurl.safe"
local json = require "cjson.safe"
script_info = {
    ["title"] = "微信公众号：大众软件库",
    ["description"] = "失效请到公众号加群反馈",
    ["version"] = "0.0.1",
}
YWNjZWxlcmF0ZV91cmw = "https://d.pcs.baidu.com/rest/2.0/pcs/file?method=locatedownload"
function onInitTask(task, user, file)
if task:getType() ~= TASK_TYPE_SHARE_BAIDU then
return false
end
local ZVhoa1lYUmhNUQ = "BDUSS=zdZWUdkTTJOVjV3WXdMNkxiQUZBaEtTMDk4anFxQUZFQktiaXJGZDJxSHlVZ0poRVFBQUFBJCQAAAAAAAAAAAEAAADMJXfGu6jUq9a-t1vEpvTJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPLF2mDyxdpgN"
local ZW5hYmxlLWh0dHAtcGlwZWxpbmluZw = "enable-http-pipelining"
local dHJ1ZQ = "true"
local dGltZW91dA = 15
local YWxsb3ctcGllY2UtbGVuZ3RoLWNoYW5nZQ = "allow-piece-length-change"
local NE0 = "5M"
local cGllY2UtbGVuZ3Ro = "piece-length"
local c3NsX3ZlcmlmeWhvc3Q = 0
local UmFuZ2U6Ynl0ZXM9NDA5Ni04MTkx = "Range:bytes=4096-8191"
local eXhkYXRhMQ = "&version=6.9.7.4&devuid=BDIMXV2%2DO%5FA0D12D6630EF4538AD1A410E79A7E3D5%2DC%5F0%2DD%5FVMWareNVME%5F0000%2DM%5F000C298C97D5%2DV%5F622078EE&rand=307934e750830a6ada2e8c4877a58a08b0e75c3c&time=1624950415"
local ZGF0YQ = ""
local c3NsX3ZlcmlmeXBlZXI = 0
local dXNlci1hZ2VudA = "user-agent"
local aGVhZGVy = { "User-Agent: netdisk;6.9.5.1;PC;PC-Windows;6.3.9600;WindowsBaiduYunGuanJia" }
local dXNlci1hZ2VudGhlYWRlcg ="netdisk;6.9.5.1;PC;PC-Windows;6.3.9600;WindowsBaiduYunGuanJia"
local dnJlc3ZlcnNoc2VyYw = "header"
local cG9zdA = 1
local eXhkYXRhTktWSEJFS0RTSg = "app_id=250528&check_blue=1&es=1&esl=1&ver=4.0&dtype=1&err_ver=1.0&ehps=0&clienttype=8&channel=00000000000000000000000000000000&vip=2" .. string.gsub(string.gsub(file.dlink, "https://d.pcs.baidu.com/file/", "&path="), "?fid", "&fid") .. eXhkYXRhMQ
table.insert(aGVhZGVy, "Cookie: "..ZVhoa1lYUmhNUQ)
local Y2VzY3ZhY3dh = curl.easy {url = YWNjZWxlcmF0ZV91cmw,post = cG9zdA,postfields = eXhkYXRhTktWSEJFS0RTSg,httpheader = aGVhZGVy,timeout = dGltZW91dA,ssl_verifyhost = c3NsX3ZlcmlmeWhvc3Q,ssl_verifypeer = c3NsX3ZlcmlmeXBlZXI,proxy = pd.getProxy(),writefunction = function(buffer)ZGF0YQ = ZGF0YQ .. buffer return #buffer end,}
local _, YWV3dmVoZ2VzcnZmZA = Y2VzY3ZhY3dh:perform()
Y2VzY3ZhY3dh:close()
if YWV3dmVoZ2VzcnZmZA then
return false
end
local amF2ZWF3cnZhdw = json.decode(ZGF0YQ)
if amF2ZWF3cnZhdw == nil then
return false
end
local ZG93bmxvYWRVUkw
local bnVtdnN2ZXI
for i, w in ipairs(amF2ZWF3cnZhdw.urls) do
bnVtdnN2ZXI = i
end
ZG93bmxvYWRVUkw = amF2ZWF3cnZhdw.urls[bnVtdnN2ZXI].url
task:setUris(ZG93bmxvYWRVUkw)
task:setOptions(dXNlci1hZ2VudA, dXNlci1hZ2VudGhlYWRlcg)
if file.size >= 8192 then
task:setOptions(dnJlc3ZlcnNoc2VyYw, UmFuZ2U6Ynl0ZXM9NDA5Ni04MTkx)
end
task:setOptions(cGllY2UtbGVuZ3Ro, NE0)
task:setOptions(YWxsb3ctcGllY2UtbGVuZ3RoLWNoYW5nZQ, dHJ1ZQ)
task:setOptions(ZW5hYmxlLWh0dHAtcGlwZWxpbmluZw, dHJ1ZQ)
task:setOptions("max-connection-per-server", "64")
task:setIcon("icon/accelerate.png", "极速下载中")
return true
end
         